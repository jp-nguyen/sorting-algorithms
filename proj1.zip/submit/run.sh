#! /bin/bash



g++ -ggdb -std=c++14 -Wpedantic -Wall -Wextra -Werror -Wzero-as-null-pointer-constant *.cpp -o proj1 && ./proj1
